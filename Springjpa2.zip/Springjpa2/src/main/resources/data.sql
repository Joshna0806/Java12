insert into student values(101,'joshna','java');
insert into student values(102,'priya','python');
insert into student values(103,'deepika','java');
insert into student values(104,'supriya','spring boot');
insert into student values(105,'abhi','python');