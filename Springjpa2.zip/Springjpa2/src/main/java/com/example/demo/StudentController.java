package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.dao.StudentRepo;
import com.example.demo.model.Student;

@Controller
public class StudentController {
	
	@Autowired
    StudentRepo repo;
	
	@RequestMapping("/")
	public String home() {
		return "home.jsp";
	}
	@PostMapping("/student")
	 @ResponseBody 
	public Student addStudent(@RequestBody Student student) {
		
		repo.save(student);
		
		return student;
		
	}
	
	@RequestMapping("/getStudent")
	public ModelAndView getStudent(@RequestParam int sid)    // RequestParam is used to fetch the value from the client 
	{
		ModelAndView mv = new ModelAndView("showStudent.jsp");
		Student student=repo.findById(sid).orElse(new Student());
		
		System.out.println(repo.findByTech("java"));
		System.out.println(repo.findBySidGreaterThan(102));
		System.out.println(repo.findByTechSorted("java"));
		
		mv.addObject(student);
		return mv;
		
	}
	
	  @GetMapping("/students")
	  
	  @ResponseBody 
	  public List<Student> getStudents() { 
		  
		  return repo.findAll();
	  
	  }
	  
	  @RequestMapping("/students/{sid}")
	  
	  @ResponseBody 
	  public Optional<Student> getStudentById(@PathVariable("sid") int sid) {
	  
		  return repo.findById(sid);
	  }
	 
	 @DeleteMapping("/student/{sid}")
	 @ResponseBody
	 public String deleteStudent(@PathVariable int sid)
	 {
		 Student s=repo.getOne(sid);
		 repo.delete(s);
		 return "deleted";
		 
	 }
	 
	 @PutMapping("/student")
	 @ResponseBody 
	public Student saveOrUpdateStudent(@RequestBody Student student) {
		
		repo.save(student);
		
		return student;
		
	}
	 
	 


}
