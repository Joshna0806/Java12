package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@Controller 
public class MyController {
	@RequestMapping("/hello")
	public String sayHello() {
		return "hello"; //"hello" is treated as a logical view name by thymeleaf and this
		                // logical view name will be resolved to the physical view name "hello.html"
		                // under src/main/resources/templates folder	
	}	
	
	
	@RequestMapping("/movie")
	public ModelAndView getMovies() {
		ModelAndView mv = new ModelAndView();  
		mv.addObject("movieName", "Top Gun");       //adding data into the model
		mv.addObject("movieActor", "Tom Cruise");   //adding data into the model
		mv.setViewName("movie");   // adding the logical view name which can display the model data.
		                           // Thymeleaf maps it to movie.html
		return mv;
		
	}
	
	//the player info is received from index.html page --> controller --> player info is sent
	// to the player.html
	// @RequestMapping(value="/player", method=RequestMethod.POST)
	@PostMapping("/player")
	public String postplayer(@ModelAttribute("player") String player)
	{
		return "player";   //player will be mapped to /templates/player.html
	}

}
