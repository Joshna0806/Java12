package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {
	
	@RequestMapping("/hello")
	public String sayHello() {
		return "hello"; //hello logical view --> /templates/hello.html

	}
	
	//data is being sent from the controller to the view using the ModelAndView object'
	
	

}
